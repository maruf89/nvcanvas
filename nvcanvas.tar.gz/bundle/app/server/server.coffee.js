var Chat, Connections, DrawingHistory, Rooms, Tools, UserList;

UserList = new Meteor.Collection('userList');

Rooms = new Meteor.Collection('rooms');

Tools = new Meteor.Collection('tools');

DrawingHistory = new Meteor.Collection('drawingHistory');

Connections = new Meteor.Collection('connections');

Chat = new Meteor.Collection('chat');

Meteor.startup(function() {
  Meteor.publish('rooms', function() {
    return Rooms.find();
  });
  Meteor.publish('tools', function() {
    return Tools.find();
  });
  Meteor.publish('drawingHistory', function(roomId) {
    return DrawingHistory.find({
      room: roomId
    });
  });
  Meteor.publish('userList', function(roomId) {
    return UserList.find({
      roomId: roomId
    });
  });
  Meteor.publish('chat', function(roomId) {
    return Chat.find({
      room: roomId
    });
  });
  Meteor.methods({
    keepalive: function(userId) {
      if (!Connections.findOne({
        userId: userId
      })) {
        Connections.insert({
          userId: userId
        });
      }
      return Connections.update({
        userId: userId
      }, {
        $set: {
          last_seen: (new Date()).getTime()
        }
      });
    }
  });
  UserList.remove({});
  Connections.remove({});
  return Meteor.setInterval(function() {
    var now, removeId, remove_id;

    now = (new Date()).getTime();
    removeId = remove_id = [];
    Connections.find({
      last_seen: {
        $lt: now - 10 * 1000
      }
    }).forEach(function(user) {
      removeId.push(user.userId);
      return remove_id.push(user._id);
    });
    if (removeId.length) {
      Meteor._debug(removeId);
      UserList.remove({
        userId: {
          $in: removeId
        }
      });
      DrawingHistory.remove({
        sid: {
          $in: removeId
        }
      });
      return Connections.remove({
        _id: {
          $in: remove_id
        }
      });
    }
  }, 5000);
});
