if (process.env.ROOT_URL)
  __meteor_runtime_config__.ROOT_URL = process.env.ROOT_URL;
