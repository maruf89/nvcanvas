require('./server/server.js');
